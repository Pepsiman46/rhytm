const queue = new Map()

exports.queue = queue